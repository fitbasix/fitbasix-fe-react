import React from 'react'
import "./styles.css"
const Home = () => {
  return (
    <div className='homeContainer'>Home</div>
  )
}

export default Home