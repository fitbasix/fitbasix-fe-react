import React from 'react'
import "./styles.css"
const GetStarted = () => {
  return (
    <div  className='getStartedContainer'>GetStarted</div>
  )
}

export default GetStarted