import React from 'react'
import "./styles.css"
const FAQ = () => {
  return (
    <div className='FAQContainer'>FAQ</div>
  )
}

export default FAQ