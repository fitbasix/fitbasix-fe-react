import React from 'react'
import "./styles.css"
const BMI = () => {
  return (
    <div className='BMIContainer'>BMI</div>
  )
}

export default BMI