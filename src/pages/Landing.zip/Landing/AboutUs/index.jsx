import React from 'react'
import "./styles.css"
const AboutUs = () => {
  return (
    <div className="aboutUsContainer">AboutUs</div>
  )
}

export default AboutUs