import React from 'react'
import "./styles.css"
const UserReviews = () => {
  return (
    <div className='userReviewsContainer'>UserReviews</div>
  )
}

export default UserReviews