import React from 'react'
import "./styles.css"
const WorkoutSessions = () => {
  return (
    <div className="workoutSessionContainer">WorkoutSessions</div>
  )
}

export default WorkoutSessions