import React from 'react'
import "./styles.css"
const PopularClasses = () => {
  return (
    <div className="popularClassesContainer">PopularClasses</div>
  )
}

export default PopularClasses